package uasoop;

public class uasOOP {

    public static void main(String[] args) {
        new fSIM().setVisible(true);
    }
    
}
